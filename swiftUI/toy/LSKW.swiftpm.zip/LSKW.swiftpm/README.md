#  구현 해야 할 것
1. 건반 이미지 - 
2. 버튼 클릭시 소리 - 
3. 클릭시 데이터 집어 넣기
4. 플레이 버튼 클릭시 소리
5. reset 버튼 구현
6. 반복문 구현
7. 이프문 구현
8. 화면 보여주는 것 구현

## 문제점
judy가 이미 구현해서 위너 된 아이디어 였다..

## 축구로 가보자.
축구 알고리즘 느낌으로 가보자.
- kick()
- pass()
- turnLeft()
- turnRight()
- goFoward()
- dribbleForward()

### 필드
5X5 부터 시작해서 10 X 10 까지

### 할일
- judy 깃허브 훔쳐보기

or

- import PlaygroundSupport 공부해보기!

